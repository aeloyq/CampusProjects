//
//  storecell2.h
//  TanChiYu
//
//  Created by 包子 on 16/5/21.
//  Copyright © 2016年 包子. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface storecell2 : UITableViewCell
@property (weak, nonatomic) IBOutlet UIButton *b0;
@property (weak, nonatomic) IBOutlet UIButton *b1;
@property (weak, nonatomic) IBOutlet UIButton *b2;

@end
