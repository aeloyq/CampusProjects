//
//  ctvc.h
//  TanChiYu
//
//  Created by 包子 on 16/5/9.
//  Copyright © 2016年 包子. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ctvc : UITableViewCell
@property (weak, nonatomic) IBOutlet UIImageView *cim;
@property (weak, nonatomic) IBOutlet UILabel *cl1;
@property (weak, nonatomic) IBOutlet UILabel *cl2;
@property (weak, nonatomic) IBOutlet UILabel *cxl;
@property (weak, nonatomic) IBOutlet UILabel *cpr;

@end
