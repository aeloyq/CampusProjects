//
//  cartvc.h
//  TanChiYu
//
//  Created by 包子 on 16/5/9.
//  Copyright © 2016年 包子. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface cartvc : UITableViewCell
@property (weak, nonatomic) IBOutlet UILabel *cl1;

@property (weak, nonatomic) IBOutlet UILabel *cl2;
@property (weak, nonatomic) IBOutlet UITextField *ct;
@property (weak, nonatomic) IBOutlet UIStepper *am;
@property (weak, nonatomic) IBOutlet UILabel *l1;
@property (weak, nonatomic) IBOutlet UILabel *l2;
@property (weak, nonatomic) IBOutlet UILabel *l3;
@property (weak, nonatomic) IBOutlet UIImageView *im;
@property (weak, nonatomic) IBOutlet UILabel *lt;
@property (weak, nonatomic) IBOutlet UILabel *lsp;
@property (weak, nonatomic) IBOutlet UILabel *ldj;


@end
